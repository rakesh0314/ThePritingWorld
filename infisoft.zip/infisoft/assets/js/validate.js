$(document).ready(function(){
	
	var addCustomer = $("#addCustomer");
	
	var validator = addCustomer.validate({
		
		rules:{
			fname :{ required : true },
			lname :{ required : true },
			email :{ required : true },
			address :{ required : true },
			countrycode :{ required : true },
			mobile :{ required : true },
			gender :{ required : true },
			country :{ required : true },
			city :{ required : true },
			pcode :{ required : true },
			

			
		},
		messages:{
			fname :{ required : "This field is required" },
			
		}
	});

});

$(document).ready(function(){
	
	var addShipment = $("#AddShipment");
	
	var validator = addShipment.validate({
		
		rules:{
			cname :{ required : true },
			email :{ required : true },
			phone :{ required : true },
			address :{ required : true },
			state :{ required : true },
			city :{ required : true },
			pcode :{ required : true },
			office_city :{ required : true },
			office :{ required : true },
			p_name :{ required : true },
			contact_no :{ required : true },
			p_email :{ required : true },
			item_name :{ required : true },
			item_description :{ required : true },  
			qty :{ required : true },
			length :{ required : true },
			width :{ required : true },
			height :{ required : true },
			weight :{ required : true },
			price :{ required : true },
			track_id :{ required : true },

			
		},
		messages:{
			fname :{ required : "This field is required" },
			
		}
	});
});

$(document).ready(function(){
	
	var addOffice = $("#addOffice");
	
	var validator = addOffice.validate({
		
		rules:{
			office :{ required : true },
			phone :{ required : true },
			address :{ required : true },
			country :{ required : true },
			state :{ required : true },
			city :{ required : true },
			pcode :{ required : true },
			name :{ required : true },
			contact :{ required : true },
			email :{ required : true },
			password :{ required : true },
			
		},
		messages:{
			fname :{ required : "This field is required" },
			
		}
	});
});


