/* Static Variables */

var ItNo = 0;

/* Sipment Item Clone */

function GetClone() {
	ItNo = ItNo + 1;
	$("#PutItemClone0").after('<tr id="PutItemClone'+ItNo+'">'+
                              '<td><input type="text" class="form-control" name=""></td>'+
                              '<td><textarea class="form-control" name=""></textarea></td>'+
                              '<th><button type="button" name="add" class="btn btn-danger btn-sm add" onclick="RemoveClone('+ItNo+')"><span class="glyphicon"><i class="fa fa-minus"></i> </span></button></th>'+
                          '</tr>');
}

function RemoveClone(CloneNo){
	ItNo = ItNo - 1;
	$("#PutItemClone"+CloneNo).remove();
}


