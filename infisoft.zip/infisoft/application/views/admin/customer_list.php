
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-users" aria-hidden="true"></i>Customers
       
      </h1>
    </section>
   
     <section class="content">
        <div class="row">
            <div class="col-xs-12 text-right">
                <div class="form-group">
                    <a class="btn btn-success" href="<?php echo base_url(); ?>addNewCustomer"><i class="fa fa-plus"></i> Add New Customers</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Customers List</h3>
                    <div class="box-tools">
                        <form action="<?php echo base_url() ?>" method="POST" id="searchList">
                            <div class="input-group">
                              <input type="text" name="searchText"  class="form-control input-sm pull-right" style="width: 150px;" placeholder="Search"/>
                              <div class="input-group-btn">
                                <button class="btn btn-sm btn-default searchList"><i class="fa fa-search"></i></button>
                              </div>
                            </div>
                        </form>
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                  <table class="table table-hover">
                    <tr>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Address</th>
                        <th>City</th>
                        <th>State</th>
                        <th class="text-center">Action</th>
                    </tr>
                    <?php
                      foreach ($getAllCustomers as $row )
                      {    
                      ?>
                    <tr>
                      <td><?= $row->f_name ?> <?= $row->l_name ?></td>
                      <td><?= $row->mobile_no ?></td>
                      <td><?= $row->email_id ?></td>
                      <td><?= $row->address ?></td>
                      <td><?= $row->city ?></td>
                      <td><?= $row->state ?></td>
                      <td  class="text-center">
                        <?=  anchor("Sipment/EditCustomer/{$row->id}",'<i class="fa fa-pencil"></i>',['class'=>'btn btn-primary']);  ?> || 
                        <?=  anchor("Sipment/Deletecustomers/{$row->id}",'<i class="fa fa-trash"></i>',['class'=>'btn btn-danger']);  ?>
                      </td>
                    </tr>
                    <?php }?>
                   
                  </table>
                  
                </div><!-- /.box-body -->
                
              </div><!-- /.box -->
            </div>
        </div>
    
     </section>
    
    
</div>
