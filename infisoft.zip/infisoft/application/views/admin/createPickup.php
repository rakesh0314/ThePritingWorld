
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-cubes"></i> Create Pickup<br>
        
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-10">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Select Cities:</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="addUser" action="<?php echo base_url() ?>addOffice" method="post" role="form">
                        <div class="box-body">

                            <div class="row">
                                <div class="col-md-1"></div>
                                <div class="col-md-10">
                                    <table class="table">
                              <thead>
                                <tr >
                                  <th scope="col">Sno</th>
                                  <th scope="col">City Name</th>
                                  <th scope="col">Total Orders</th>
                                  <th scope="col">Action</th>
                                </tr>
                              </thead>
                              <tbody>
                                <?php
                                $sno=1;
                                  foreach ($getpickupoffice as $row )
                                  {    
                                  ?>
                                <tr>
                                  <td scope="row"><?= $sno?></td>
                                  <td><?= $row->city ?></td>
                                  </td>
                                  <td></td>
                                  <td><input type="checkbox" name=""></td>
                                </tr>
                                <?php $sno++;}  ?>
                              </tbody>
                            </table>
                                </div>
                                <div class="col-md-1"></div>
                            </div>
                        </div>
                        <br>
                        <div class="box-header">
                        <h3 class="box-title">Select Office:</h3>
                        </div>
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-1"></div>
                                <div class="col-md-10">
                                    <table class="table">
                                      <thead>
                                        <tr >
                                          <th scope="col">Sno</th>
                                          <th scope="col">Office Name</th>
                                          <th scope="col">City Name</th>
                                          <th scope="col">Contact Person Name</th>
                                          <th scope="col">Contact No</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        <tr>
                                          <th scope="row">1</th>
                                          <td>Ekart</td>
                                          <td>Bhilai</td>
                                          <td>Mr. Gajendra</td>
                                          <td>6262451420</td>
                                        </tr>
                                        <tr>
                                          <th scope="row">2</th>
                                          <td>Courier</td>
                                          <td>Balod</td>
                                          <td>Mr. Mayank</td>
                                          <td>9300114522</td>
                                        </tr>
                                      </tbody>
                                    </table>
                                </div>
                                <div class="col-md-1"></div>
                            </div>
                        </div>
                        <div class="box-header">
                        <h3 class="box-title">Select Orders:</h3>
                        </div>

                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-1"></div>
                                <div class="col-md-10">
                                    <table class="table">
                              <thead>
                                <tr >
                                  <th scope="col">Sno</th>
                                  <th scope="col">Customer Name</th>
                                  <th scope="col">City Name</th>
                                  <th scope="col">Item Qty.</th>
                                  <th scope="col">Action</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <th scope="row">1</th>
                                  <td>Chhotu</td>
                                  <td>Bhilai</td>
                                  <td>1</td>
                                  <td><input type="checkbox" name=""></td>
                                </tr>
                                <tr>
                                  <th scope="row">2</th>
                                  <td>Bhushan</td>
                                  <td>Balod</td>
                                  <td>2</td>
                                  <td><input type="checkbox" name=""></td>
                                </tr>
                                <tr>
                                  <th scope="row">3</th>
                                  <td>Golu</td>
                                  <td>Balod</td>
                                  <td>4</td>
                                  <td><input type="checkbox" name=""></td>
                                </tr>
                                <tr>
                                  <th scope="row">4</th>
                                  <td>Sonu</td>
                                  <td>Balod</td>
                                  <td>3</td>
                                  <td><input type="checkbox" name=""></td>
                                </tr>
                                
                              </tbody>
                            </table>

                                </div>
                                <div class="col-md-1"></div>
                            </div>
                            

                        
                    
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    
</div>
<script src="<?php echo base_url(); ?>assets/js/addUser.js" type="text/javascript"></script>