<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-cube"></i>Pickup Reports<br>
        
      </h1>
   </section>
   <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title"><b>PDF Reports :</b></h3>
                        <h5 style="color: gray;">All Pickup by date range</h5>
                    </div><!-- /.box-header -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="addUser" action="<?php echo base_url() ?>addOffice" method="post" role="form">
                    	<div class="box-body">

                            <div class="row">
                                <div class="col-md-1"></div>
                                <div class="col-md-10">
                                    <div class="row">
                                    	<div class="col-md-4 form-group">
                                    		<input type="date" name="start_date" class="form-control" id="dateicker">
                                    	</div>
                                    	<div class="col-md-1"><b>to</b></div>
                                    	<div class="col-md-4 form-group">
                                    		<input type="date" name="end_date" class="form-control" id="dateicker">
                                    	</div>
                                    	<div class="col-md-2">
                                    	<a href=""><img src="assets/images/pdf.png" height="40px" width="40px"></a>
                                   		</div>
                                    </div>
                                    <br>
                                   <div class="box-body table-responsive no-padding">
					                  <table class="table table-hover">
					                    <tr>
					                        <th>Tracking</th>
					                        <th>Office Name</th>
					                        <th>Address</th>
					                        <th>Date and Time of Pickup</th>
					                        <th>Qty.</th>
					                        <th>Status</th>
					                    </tr>
					                   
					                  </table>
					                  
					                </div>
                                </div>
                            </div>
                        </div>
                    </form>           
              	</div>
            </div>
        </div>
    </section>
</div>

