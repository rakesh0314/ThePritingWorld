
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-users"></i>Customer
        <small>Edit Customer</small>
        
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-10">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Update Customer Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="addCustomer" action="<?php echo base_url() ?>editCustomer" method="post" role="form">
                        <div class="box-body">
                           
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="fname">First Name:</label>
                                        <input type="text" class="form-control "  id="fname" name="fname" maxlength="128" value="<?= $edit_customers->f_name ?>" oninput="this.value = this.value.replace(/[^A-z a-z.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');">
                                    </div>
                                    
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="last name">Last Name:</label>
                                        <input type="text" class="form-control  "  id="lname" name="lname" maxlength="128" value="<?= $edit_customers->l_name ?>" oninput="this.value = this.value.replace(/[^A-z a-z.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');">
                                    </div>
                                    
                                </div>
                                
                            </div>
                            <div class="row">
                               <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="email">Email address:</label>
                                        <input type="text" class="form-control   email" id="email"  name="email" maxlength="128" value="<?= $edit_customers->email_id ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="address">Address:</label>
                                    
                                        <textarea class="form-control   " id="address" name="address" value="<?= $edit_customers->address ?>"><?= $edit_customers->address ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="gender">Gender:</label>
                                        <select class="form-control  " id="gender" name="gender">
                                            <option selected value="<?= $edit_customers->gender ?>">
                                                <?php
                                                    if ($edit_customers->gender==1) 
                                                    {
                                                        echo "Male";
                                                    }
                                                    else
                                                    {
                                                        if ($edit_customers->gender==2) 
                                                        {
                                                            echo "Female";
                                                        }
                                                        else
                                                        {
                                                            echo "Other";
                                                        }
                                                    }
                                                ?>
                                            </option>
                                            <option value="1">Male</option>
                                            <option value="2">Female</option>
                                            <option value="3">Other</option>
                                            
                                        </select>
                                    </div>
                                </div>   
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="mobile">Mobile Number:</label>
                                        <div class="row">
                                            <div class="col-md-4 m-r-0">
                                                    <select  class="form-control required" name="countrycode">
                                             
                                                         <option selected value="<?= $edit_customers->con_code ?>"><?= $edit_customers->con_code ?></option>
                                                         
                                                     </select>
                                                </div>
                                                <div class="col-md-8 m-l-0">
                                                    <input type="text" class="form-control   digits" id="mobile"  name="mobile" maxlength="10" value="<?= $edit_customers->mobile_no ?>" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');">
                                                </div>
                                                
                                           </div>       
                                        </div>
                                     
                                </div>
                                 
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="State">State:</label>
                                        <select class="form-control" name="state" onchange="GetCitys(this)">
                                            <option value="<?= $edit_customers->state ?>" selected ><?= $edit_customers->state ?></option>
                                            <?php 
                                                foreach ($getallstate as $row ){    
                                                     ?>
                                                     <option><?= $row->city_state ?></option>
                                            <?php
                                                   
                                                }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="City">City:</label>
                                        <select class="form-control" name="city" id="CityTxtId">
                                            <option value="<?= $edit_customers->city ?>" selected><?= $edit_customers->city ?></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="Postal Code">Postal Code:</label>
                                         <input type="text" class="form-control  " id="pcode"  name="pcode" value="<?= $edit_customers->postal_code ?>" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');">
                                    </div>
                                </div>    
                            </div>
                            <div class="row">
                               <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="Unotes">User Notes - For internal use only.</label><br>
                                        <textarea class="form-control" rows="6" value="<?= $edit_customers->note_remark ?>" name="usernotes" id="usernotes"><?= $edit_customers->note_remark ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->

                        <input type="hidden" name="customerid" value="<?= $edit_customers->id ?>">
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-info" value="Save" />
                            
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>      
    
</div>
<script src="<?php echo base_url(); ?>assets/js/validate.js" type="text/javascript"></script>


<script type="text/javascript">
    
    function GetCitys(val){

         $.ajax({
          url: baseURL+'Sipment/getCitys',
          type: "POST",
          data: {'stateName':val.value},
          success: function(data, textStatus) {
        
                $("#CityTxtId").html(data)          
            
          },
          error: function(jqXHR, textStatus, errorThrown) {
              alert('Error occurred!');
          }
      });
    }
</script>