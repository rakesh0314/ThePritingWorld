<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-cube"></i>Update Shipments<br>
        <?php 
              foreach ($Sender as $s_row) 
              {
                if($s_row->id==$shipment_details->customer_id)
                { ?>
                  <h4>You're shipping from: <b><?= $s_row->city ?>,<?= $s_row->state ?> </b></h4>
                 <h4>Sender's name: <b><?= $s_row->f_name ?> <?= $s_row->l_name ?></b></h4>
                  <h4>Phone: <b><?= $s_row->mobile_no ?></b></h4>

              <?php  }
              }

        ?>
      </h1>
    </section>
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-12" style="margin-left: 10px;">

             <?php $this->load->helper("form"); ?>
                    <form role="form" id="AddShipment" action="<?php echo base_url() ?>EditShipment" method="post" role="form">
              <!-- general form elements -->

               <div class="row box box-primary">
                   <div class="col-md-6">
                        <div class="box-header">
                        <h3 class="box-title">Customer Information:</h3>
                         </div>
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="Cname">Receiver Name:</label>
                                        <input type="text" class="form-control  " id="cname" name="r_name" maxlength="128" value="<?= $shipment_details->receiver_name ?>" oninput="this.value = this.value.replace(/[^A-z a-z]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="email">Email address:</label>
                                        <input type="text" class="form-control   email" id="email" value="<?= $shipment_details->email_id ?>" name="email" maxlength="128">
                                    </div>
                                </div>   
                            </div>

                            <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="Phone">Mobile No:</label>
                                        <input type="text" class="form-control  " id="phone" value="<?= $shipment_details->mobile_no ?>" name="phone" maxlength="10" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');">
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="Full Address">Full Address:</label>
                                        <textarea class="form-control" id="address" name="address" value="<?= $shipment_details->address ?>"><?= $shipment_details->address ?></textarea>
                                    </div>
                                </div>     
                             </div>
                             <div class="row">
                                 <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="State">State:</label>
                                        <select class="form-control" name="state" onchange="GetCitys(this)">
                                            <option value="<?= $shipment_details->state ?>" selected><?= $shipment_details->state ?></option>
                                            <?php 
                                                foreach ($getallstate as $row ){    
                                                     ?>
                                                     <option><?= $row->city_state ?></option>
                                            <?php
                                                   
                                                }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="City">City:</label>
                                        
                                        <select class="form-control" name="city" id="CityTxtId">
                                            
                                            <?php foreach ($GetAllCity as $CitysRow) { 

                                              ?>
                                              <option value="<?= $CitysRow->city_name ?>"<?php if( $CitysRow->city_name == $shipment_details->city ){ echo "selected";} ?>><?= $CitysRow->city_name ?></option>
                                          <?php  } ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="Postal Code">Postal Code:</label>
                                        <input type="text" class="form-control  " value="<?= $shipment_details->postal_code ?>" id="pcode" name="pcode" oninput="this.value = this.value.replace(/[^0-9]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');">
                                    </div>    
                                </div>
                            </div>
                        </div><!-- /.box-body -->
                   </div>

                   <div class="col-md-6">
                        <div class="box-header">
                            <h3 class="box-title">Select Office:</h3>
                        </div>
                     <div class="box-body">
                      <?php 
                         foreach ($getoffice as $o_row) 
                         {

                           if($o_row->id==$shipment_details->office_id)
                         {?>
                        <div class="row">
                          
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="office city">Select City:</label>
                                        <select class="form-control" name="OfficeCity" id="OfficeCity">
                                          
                                            <?php foreach ($GetAllCity as $CitysRow) { ?>
                                              <option value="<?= $CitysRow->city_name ?>" <?php if($o_row->city == $CitysRow->city_name ){ echo "selected";} ?>><?= $CitysRow->city_name ?></option>
                                          <?php  } ?>
                                          </select>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="Select Office">Select Office:</label>
                                        <select class="form-control"id="office" name="office" onchange="GetPersonDetails(this)">
                                            <option value="<?= $o_row->id ?>" selected><?= $o_row->office_name ?></option>
                                          <?php  
                                            foreach ($getoffice as $office) 
                                            { ?>
                                               <option value="<?= $office->id ?>" selected><?= $office->office_name ?></option>
                                          <?php }
                                          ?>

                                        </select>
                                    
                                    </div>
                                </div>

                                
                                
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="Person Name">Contact Person Name:</label>
                                            <input type="text" class="form-control  " id="p_name"  name="p_name" value="<?= $o_row->con_name?>" oninput="this.value = this.value.replace(/[^A-z a-z]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');">
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="Mobile" >Contact No :</label>
                                             <input type="text" class="form-control    " id="contact_no" name="contact_no" maxlength="10" value="<?= $o_row->cont_name?>" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="Email">Email Address:</label>
                                             <input type="text" class="form-control " id="p_email" name="p_email" value="<?= $o_row->email?>">
                                    </div>
                                </div>   
                            </div>

                              <?php }
                             }

                           ?>
                                        
                         </div>
                     </div> 
                     <div class="row">
                        <div class="col-md-11" style="margin-left: 20px;">
                            <div class="box-header">
                                <h3 class="box-title">Item Details:</h3>
                            </div> 
                            <div class="box-body">
                            <div class="row">

                              <div class="table-repsonsive">
                                 <span id="error"></span>
                                 <table class="table" id="item_table">
                                  <tr>
                                   <th>Item Type:</th>
                                   <th>Item Name:</th>
                                   <th>Item Description:</th>
                                                             
                                   <th>&nbsp;</th>
                                  </tr>
                                  <tr id="PutItemClone0">
                                      <td>
                                        <select class="form-control" id="item_type" name="item_type">
                                          <?php 
                                                foreach ($getItemType as $i_row ){    
                                                  if ($i_row->id==$shipment_details->item_type){
                                                     ?>
                                                    <option value="<?= $i_row->id ?>" selected required><?= $i_row->name_item ?></option>
                                                  <?php
                                                  }
                                                }
                                            ?>
                                            <?php 
                                                foreach ($getItemType as $row ){    
                                                     ?>
                                                     <option value="<?= $row->id ?>"><?= $row->name_item ?></option>
                                            <?php
                                                   
                                                }
                                            ?>
                                        </select>
                                      </td>
                                      <td><input type="text" class="form-control" id="item_name" name="item_name" value="<?=$shipment_details->item_name ?>" required></td>
                                      <td><textarea class="form-control" id="item_description" name="item_description" value="<?=$shipment_details->item_desc ?>" required><?=$shipment_details->item_desc ?></textarea></td>
                                     <!--  <th><button type="button" name="add" class="btn btn-success btn-sm add" onclick="GetClone()"><span class="glyphicon"><b> + </b></span></button></th> -->
                                  </tr>
                                 </table>
                            </div>
                        <div class="box-header">
                                <h3 class="box-title">Packaging Details:</h3>
                            </div>

                                
                        <div class="box-body">
                            <div class="row">
                               <div class="col-md-4">
                                    <div class="form-group">
                                         <label for="Quantity">Quantity:</label>
                                            <input type="text" class="form-control" value="<?=$shipment_details->qty ?>" id="qty" name="qty" oninput="this.value = this.value.replace(/[^0-9]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');">
                                    </div>
                                </div>
                               
                                <div class="col-md-6">
                                    <div class="form-group">
                                         <label for="Phone">Dimensions: Length  x  Width  x  Height (cm) :</label>
                                           <div class="row">
                                                <div class="col-md-3">
                                                    <input type="text" class="form-control    " id="length" name="length" value="<?=$shipment_details->length ?>"  oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');">
                                                </div>
                                                <div class="col-md-1">x</div>
                                                <div class="col-md-3">
                                                    <input type="text" class="form-control    " id="width" name="width" value="<?=$shipment_details->width ?>" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');">
                                                </div>
                                                <div class="col-md-1">x</div>
                                                <div class="col-md-3">
                                                    <input type="text" class="form-control    " id="height"  name="height" value="<?=$shipment_details->height ?>" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');">
                                                </div>
                                           </div>
                                    </div>
                                </div>
                            
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                         <label for="Weight">Weight:</label>
                                            <div class="row">
                                                <div class="col-md-8 m-r-0">
                                                    <input type="text" class="form-control    " id="weight"  name="weight" value="<?=$shipment_details->weight ?>" oninput="this.value = this.value.replace(/[^0-9 . .]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');">
                                                </div>
                                                <div class="col-md-4 m-l-0">
                                                    <select  class="form-control  " name="unit">
                                                          <option value="<?=$shipment_details->unit ?>"><?=$shipment_details->unit ?></option>
                                                         <option value="kg">kg</option>
                                                         <option value="gram">gram</option>
                                                     </select>
                                                </div>
                                           </div>
                                            
                                       
                                    </div>
                                </div>
                                
                                <div class="col-md-2">
                                    <div class="form-group">
                                         <label for="Price">Price:</label>
                                            <input type="text" class="form-control" value="<?=$shipment_details->price ?>" id="price" name="price" oninput="this.value = this.value.replace(/[^0-9 . .]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');">
                                    </div>
                                </div>
                                 
                            </div>
            
                        </div>

                     </div>

                      <input type="hidden" name="shipmentid" value="<?= $shipment_details->id ?>">
                        <div class="box-footer">
                            <input type="submit" class="btn btn-info" value="Update" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    
</div>

</script>


<script src="<?php echo base_url(); ?>assets/js/validate.js" type="text/javascript"></script>

<script type="text/javascript">

    function GetPersonDetails(office){
        
        var postData = {id:office.value};
            
            $.ajax({
                url: baseURL+'Sipment/getOfficeOther',
                type: "POST",
                data: postData,
                dataType: "json",
                success: function(data, textStatus){
                   console.log(data);
                   $("#p_name").val(data.con_name);
                   $("#contact_no").val(data.cont_name);
                   $("#p_email").val(data.email);

                },
                error: function(jqXHR, textStatus, errorThrown) {
                    alert('Error occurred!');
                }
            });
    }
    
    function GetCitys(val){

         $.ajax({
          url: baseURL+'Sipment/getCitys',
          type: "POST",
          data: {'stateName':val.value},
          success: function(data, textStatus) {
        
                $("#CityTxtId").html(data);
                $("#OfficeCity").html(data);          
            
          },
          error: function(jqXHR, textStatus, errorThrown) {
              alert('Error occurred!');
          }
      });
    }
</script>