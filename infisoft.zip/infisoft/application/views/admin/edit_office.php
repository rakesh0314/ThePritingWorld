
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-building"></i>Office<br>
        <small>Edit Office</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-10">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Office Information:</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="addOffice" action="<?php echo base_url() ?>editOffice" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="Office Name">Office Name:</label>
                                        <input type="text" class="form-control " id="office" name="office" maxlength="128"  value="<?= $edit_office->office_name ?>">
                                    </div>
                                </div>

                               

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="Phone">Phone:</label>
                                        <input type="text" class="form-control   digits" id="phone" name="phone"  value="<?= $edit_office->phone_no ?>" maxlength="10" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');">
                                    </div>
                                </div>
                                
                            </div>

                            <div class="row">
                                  <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="Address">Address:</label>
                                        <textarea  class="form-control  " id="address"  name="address" value="<?= $edit_office->address ?>" ><?= $edit_office->address ?></textarea>
                                        
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="country">Country:</label>
                                        <input type="text" class="form-control  " id="country"  name="country" maxlength="120" value="<?= $edit_office->country ?>" oninput="this.value = this.value.replace(/[^A-z a-z -]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="State">State:</label>
                                        <select class="form-control" name="state" onchange="GetCitys(this)">
                                            <option value="<?= $edit_office->state ?>" selected><?= $edit_office->state ?></option>
                                            <?php 
                                                foreach ($getallstate as $row ){    
                                                     ?>
                                                     <option value="<?= $row->city_state ?>"><?= $row->city_state ?></option>
                                            <?php
                                                   
                                                }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="City">City:</label>
                                        <select class="form-control" name="city" id="CityTxtId">
                                            <option value="<?= $edit_office->city ?>" selected ><?= $edit_office->city ?></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="Postal Code">Postal Code:</label>
                                         <input type="text" class="form-control  " id="pcode" name="pcode" maxlength="10" value="<?= $edit_office->postal_code ?>" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');"
                                         >
                                    </div>
                                </div>    
                            </div>
                            
                        </div><!-- /.box-body -->
                        <div class="box-header">
                        <h3 class="box-title">Contact Person:</h3>
                        </div>

                        
                    <div class="box-body">
                    <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="name">Name:</label>
                                        <input type="text" class="form-control  "  id="name" name="name" maxlength="128" value="<?= $edit_office->con_name ?>" oninput="this.value = this.value.replace(/[^A-z a-z.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');">
                                    </div>
                                </div>

                               

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="Contact">Contact No :</label>
                                        <input type="text" class="form-control   digits" id="contact" name="contact" value="<?= $edit_office->cont_name ?>" maxlength="10" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');">
                                    </div>
                                </div>
                                
                            </div>

                            <div class="row">
                                
                                 <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="email">Email address:</label>
                                        <input type="text" class="form-control   email" id="email" name="email" maxlength="128" value="<?= $edit_office->email ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="Password">Password:</label>
                                        <input type="Password" class="form-control  "  id="password" name="password" maxlength="16" value="<?= $edit_office->password ?>">
                                    </div>
                                </div>
                            </div>

                            <input type="hidden" name="officeid" value="<?= $edit_office->id ?>">
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-success" value="Save" style="width: 80px;" />
                            
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    
</div>
<script src="<?php echo base_url(); ?>assets/js/validate.js" type="text/javascript"></script>

<script type="text/javascript">
    
    function GetCitys(val){

         $.ajax({
          url: baseURL+'Sipment/getCitys',
          type: "POST",
          data: {'stateName':val.value},
          success: function(data, textStatus) {
        
                $("#CityTxtId").html(data)          
            
          },
          error: function(jqXHR, textStatus, errorThrown) {
              alert('Error occurred!');
          }
      });
    }
</script>