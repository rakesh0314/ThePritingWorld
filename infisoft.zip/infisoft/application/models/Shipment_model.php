<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : Login_model (Login Model)
 * Login model class to get to authenticate user credentials 

 * @version : 1.1
 * @since : 15 November 2016
 */
class Shipment_model extends CI_Model
{

   public function getitem()
   {	
   		// $this->db->select('count(DISTINCT(accessid))');
   	$this->db->select('*');
		$this->db->from('tbl_itme_category');
		$this->db->order_by('name_item','asc');
		$query = $this->db->get();
		return $query->result();
   }
   public function getstate()
   {  
      // $this->db->select('count(DISTINCT(accessid))');
      $this->db->select('DISTINCT(city_state)');
      $this->db->from('tbl_cities');
      $this->db->order_by('city_state','asc');
      $query = $this->db->get();
      return $query->result();
   }
   public function getpickupoffice()
   {  
      // $this->db->select('count(DISTINCT(accessid))');
      $this->db->select('DISTINCT(city)');
      $this->db->from('tbl_shipment');
      $query = $this->db->get();
      return $query->result();
   }

   public function getCityByState($data = ""){
   		$this->db->select('*');
		$this->db->from('tbl_cities');
		$this->db->where($data);
		$query = $this->db->get();
		return $query->result();
   }
   public function getOfficeByCity($data = ""){
         $this->db->select('*');
      $this->db->from('tbl_offices');
      $this->db->where($data);
      $query = $this->db->get();
      return $query->result();
   }

   public function SetNewCustomer($data = ""){
   	$insert = $this->db->insert('tbl_customers',$data);
		return $this->db->insert_id();
   }
   public function SetNewShipment($data = ""){
      $insert = $this->db->insert('tbl_shipment',$data);
      return $this->db->insert_id();
   }
   
   public function SetNewOffice($data = "")
   {  

   		$insert = $this->db->insert('tbl_offices',$data);
		return $this->db->insert_id();
   }

   public function getcustomers()
   {	
   		$this->db->select('*');
		$this->db->from('tbl_customers');
      $this->db->where('status',1);
		$query = $this->db->get();
		return $query->result();
   }

   public function getoffice()
   {	
   		$this->db->select('*');
		$this->db->from('tbl_offices');
      $this->db->where('status',1);
		$query = $this->db->get();
		return $query->result();
   }

   public function getshipment()
   {  
      $this->db->select('*');
      $this->db->from('tbl_shipment');
      $this->db->where('status',1);
      $query = $this->db->get();
      return $query->result();
   }
   
   public function getofficedetail($data="")
   {
   	$this->db->select('*');
		$this->db->from('tbl_offices');
		$this->db->where('id',$data);
		$query = $this->db->get();
		return $query->row();
   }
   public function UpdateOffice($data ="")
   {
      $id= $this->input->post('officeid');
      
      return $this->db->where('id',$id)
                         ->update('tbl_offices',$data);

   }

   public function getCustomerdetail($data="")
   {
      $this->db->select('*');
      $this->db->from('tbl_customers');
      $this->db->where('id',$data);
      $query = $this->db->get();
      return $query->row();
   }
   public function getCustomer($data="")
   {
      $this->db->select('*');
      $this->db->from('tbl_customers');
      $query = $this->db->get();
      return $query->result();
   }
   public function UpdateCustomer($data ="")
   {
      $id= $this->input->post('customerid');

      return $this->db->where('id',$id)
                         ->update('tbl_customers',$data);

   }
   public function deleteOffice($data="")
   {
     
        
    $status = array('status' =>0);
   
      return $this->db->where('id',$data)
                      ->update('tbl_offices',$status);
   }
   public function deleteCustomer($data="")
   {
     
        
    $status = array('status' =>0);
   
      return $this->db->where('id',$data)
                      ->update('tbl_customers',$status);
   }
    public function deleteshipment($data="")
   {
     
        
    $status = array('status' =>0);
   
      return $this->db->where('id',$data)
                      ->update('tbl_shipment',$status);
   }
   public function getshipmentdetail($data="")
   {
      $this->db->select('*');
      $this->db->from('tbl_shipment');
      $this->db->where('id',$data);
      $query = $this->db->get();
      return $query->row();
   }
   public function Update_Shipment($data ="")
   {
      $id= $this->input->post('shipmentid');

      return $this->db->where('id',$id)
                         ->update('tbl_shipment',$data);

   }

   /* Shipmet Office Get Info */
    public function getOfficeInfo($data="")
   {
      $this->db->select('*');
      $this->db->from('tbl_offices');
      $this->db->where('id',$data);
      $query = $this->db->get();
      return $query->row();
   }
}
