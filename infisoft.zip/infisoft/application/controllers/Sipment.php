<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : User (UserController)
 * User Class to control all user related operations.
 
 * @version : 1.1
 * @since : 15 November 2016
 */
class Sipment extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('shipment_model');
        $this->isLoggedIn();   
    }


    function newshipment()
    {   
        $this->global['pageTitle'] = 'Shipment List';
        $this->data['getAllCustomers']=$this->shipment_model->getcustomers();
        $this->loadViews("admin/newshipment", $this->global, $this->data , NULL);
        
    }
    function addNewCustomer()
    {
        $this->global['pageTitle'] = 'Add New Customer';
        $this->data['getallstate']=$this->shipment_model->getstate();

        $this->loadViews("admin/addNewCustomer", $this->global, $this->data , NULL);
   
    }
     function CustomerList()
    { 
        $this->global['pageTitle'] = 'Customers List';
        $this->data['getAllCustomers']=$this->shipment_model->getcustomers();
        $this->loadViews("admin/customer_list", $this->global, $this->data , NULL);
   
    }
   public function addCustomer(){
        
        $data = array('f_name'=>$this->input->post('fname'),'l_name'=>$this->input->post('lname'),'email_id'=>$this->input->post('email'),'address'=>$this->input->post('address'),'con_code'=>$this->input->post('countrycode'),'mobile_no'=>$this->input->post('mobile'),'gender'=>$this->input->post('gender'),'country_name'=>'India','state'=>$this->input->post('state'),'city'=>$this->input->post('city'),'postal_code'=>$this->input->post('pcode'),'note_remark'=>$this->input->post('usernotes'),'crt_by'=>$this->session->userdata('userId'));
        $result = $this->shipment_model->SetNewCustomer($data);
        if($result){
            redirect('CustomerList');
        }
    }

    function shipmentlist()
    {
        $this->global['pageTitle'] = 'Shipment List';
        $this->data['shipment']=$this->shipment_model->getshipment();
        $this->data['getAlloffice']=$this->shipment_model->getoffice();
        $this->data['getAllCustomers']=$this->shipment_model->getcustomers();
        $this->loadViews("admin/shipmentlist", $this->global, $this->data , NULL);
   
    }
     function addCourier()
    {
        $this->global['pageTitle'] = 'Add Shipment';
        
        $this->loadViews("admin/add_courier", $this->global, NULL , NULL);
   
    }
     function OfficeList()
    {
        $this->global['pageTitle'] = 'Office List';
        $this->data['getAlloffice']=$this->shipment_model->getoffice();
        $this->loadViews("admin/office_list", $this->global, $this->data , NULL);
   
    }
    function addNewOffice()
    {
        $this->global['pageTitle'] = 'Add New Office';
        $this->data['getallstate']=$this->shipment_model->getstate();
        $this->loadViews("admin/add_office", $this->global, $this->data , NULL);
    }
    public function addOffice()
    {  
    
       $data = array('office_name'=>$this->input->post('office'),'phone_no'=>$this->input->post('phone'),'address'=>$this->input->post('address'),'country'=>$this->input->post('country'),'state'=>$this->input->post('state'),'city'=>$this->input->post('city'),'postal_code'=>$this->input->post('pcode'),'con_name'=>$this->input->post('name'),'cont_name'=>$this->input->post('contact'),'email'=>$this->input->post('email'),'password'=>$this->input->post('password'),'crt_by'=>$this->session->userdata('userId'));

        $result = $this->shipment_model->SetNewOffice($data);
        echo $result;
        if($result){
            redirect('OfficeList');
        }
    }
    
    function CreateNewShipment($id)
    {
        $this->global['pageTitle'] = 'Create New Shipment';
        $this->data['getallstate']=$this->shipment_model->getstate();
        $this->data['getItemType']=$this->shipment_model->getitem();
        $this->data['getoffice']=$this->shipment_model->getoffice();
        $this->data['Sender']=$this->shipment_model->getCustomerdetail($id);
        $this->loadViews("admin/CreateNewShipment", $this->global, $this->data , NULL);
        
       
    }
    function AddShipment()
    {
    	 $weight= $this->input->post('weight').$this->input->post('unit');
         $tracking_id = $this->input->post('code').$this->input->post('track_id');
        

        $data = array('customer_id'=>$this->input->post('customer_id'),' office_id'=>$this->input->post('office'),'receiver_name'=>$this->input->post('r_name'),'email_id'=>$this->input->post('email'),'mobile_no'=>$this->input->post('phone'),'address'=>$this->input->post('address'),'state'=>$this->input->post('state'),'city'=>$this->input->post('city'),'postal_code'=>$this->input->post('pcode'),'item_type'=>$this->input->post('item_type'),'item_name'=>$this->input->post('item_name'),'item_desc'=>$this->input->post('item_description'),'qty'=>$this->input->post('qty'),'length'=>$this->input->post('length'),'width'=>$this->input->post('width'),'height'=>$this->input->post('height'),'weight'=>$this->input->post('weight'),'unit'=>$this->input->post('unit'),'price'=>$this->input->post('price'),'tracking_id'=>$tracking_id,'crt_by'=>$this->session->userdata('userId'));
            
        $result = $this->shipment_model->SetNewShipment($data);
        if($result){
            redirect('shipmentlist');
        }
        else
        {
            echo "failed";
        }
    }
    function createPickup()
    {
    	$this->global['pageTitle'] = 'Create Pickup';
        $this->data['getpickupoffice']=$this->shipment_model->getpickupoffice();
        $this->loadViews("admin/createPickup", $this->global, $this->data , NULL);

    }
    function AllReports()
    {
    	$this->global['pageTitle'] = 'All Reports';
        
        $this->loadViews("admin/allReports", $this->global, NULL , NULL);
    }
    function PickupReports()
    {
    	$this->global['pageTitle'] = 'Pickup Reports';
        
        $this->loadViews("admin/pickup_reports", $this->global, NULL , NULL);
    }
    function DeliveredReports()
    {
    	$this->global['pageTitle'] = 'Delivered Reports';
        
        $this->loadViews("admin/delivered_reports", $this->global, NULL , NULL);
    }


    /* Get All Citys by State */ 

    public function getCitys(){
        $output="";
        $data = array('city_state' => $this->input->post('stateName'));
        $result = $this->shipment_model->getCityByState($data);
        if(count($result)>0){

          foreach($result as $row)
          {
            $output .= '<option value="'.$row->city_name.'">'.$row->city_name.'</option>';
          }
        }else{
         $output="<option>No citys an available</option>";
        }
      echo  $output;
    }

    /* Get All office by city */ 

    public function getOfficeOther(){
        $data = $this->shipment_model->getOfficeInfo($this->input->post('id'));

        echo json_encode( $data );
    }

    public function getOffice(){
        $output="";
        $data = array('city' => $this->input->post('cityName'));
        $result = $this->shipment_model->getOfficeByCity($data);
        if(count($result)>0){
           $output="<option>Select Office</option>"; 
          foreach($result as $row)
          {
            $output .= '<option value="'.$row->id.'">'.$row->office_name.'</option>';
          }
        }else{
         $output="<option>No Office an available</option>";
        }
      echo  $output;
    }

    public function editoffice($id)
    {
        $this->global['pageTitle'] = 'Office Detail';
        $this->data['getallstate']=$this->shipment_model->getstate();
        $this->data['edit_office']=$this->shipment_model->getofficedetail($id);
        $this->loadViews("admin/edit_office", $this->global, $this->data , NULL);
    }
    public function edit_Office()
    {   
        // $id= $this->input->post('officeid');
        $data = array('office_name'=>$this->input->post('office'),'phone_no'=>$this->input->post('phone'),'address'=>$this->input->post('address'),'country'=>$this->input->post('country'),'state'=>$this->input->post('state'),'city'=>$this->input->post('city'),'postal_code'=>$this->input->post('pcode'),'con_name'=>$this->input->post('name'),'cont_name'=>$this->input->post('contact'),'email'=>$this->input->post('email'),'password'=>$this->input->post('password'),'crt_by'=>$this->session->userdata('userId'));

        $result = $this->shipment_model->UpdateOffice($data);
        echo $result;

        if($result){
            redirect('OfficeList');
        }
    }

    public function EditCustomer($id)
    {   
        
        $this->global['pageTitle'] = 'Edit Customer';
        $this->data['getallstate']=$this->shipment_model->getstate();
        $this->data['edit_customers']=$this->shipment_model->getCustomerdetail($id);
        $this->loadViews("admin/edit_customers", $this->global, $this->data , NULL);
    }
    public function edit_Customer()
    {
        $data = array('f_name'=>$this->input->post('fname'),'l_name'=>$this->input->post('lname'),'email_id'=>$this->input->post('email'),'address'=>$this->input->post('address'),'con_code'=>$this->input->post('countrycode'),'mobile_no'=>$this->input->post('mobile'),'gender'=>$this->input->post('gender'),'country_name'=>'India','state'=>$this->input->post('state'),'city'=>$this->input->post('city'),'postal_code'=>$this->input->post('pcode'),'note_remark'=>$this->input->post('usernotes'),'crt_by'=>$this->session->userdata('userId'));
        $result = $this->shipment_model->UpdateCustomer($data);
        if($result){
            redirect('CustomerList');
        } 
    }
    public function Deleteoffice($id)
    {   
        
       $result = $this->data=$this->shipment_model->deleteOffice($id);
        if($result){
            redirect('OfficeList');
        } 
    }
    public function Deletecustomers($id)
    {
        $result = $this->data=$this->shipment_model->deleteCustomer($id);
        if($result){
            redirect('CustomerList');
        } 
    }
    public function Deleteshipment($id)
    {
        $result = $this->data=$this->shipment_model->deleteshipment($id);
        if($result){
            redirect('shipmentlist');
        } 
    }
    public function EditShipment($id)
    {
        $this->global['pageTitle'] = 'Shipment Detail';
        $this->data['getallstate']=$this->shipment_model->getstate();
        $this->data['shipment_details']=$this->shipment_model->getshipmentdetail($id);
        $data = array('city_state' => $this->data['shipment_details']->state);
        $this->data['GetAllCity'] = $this->shipment_model->getCityByState($data);
        
        $this->data['getItemType']=$this->shipment_model->getitem();
        $this->data['getoffice']=$this->shipment_model->getoffice();
        $this->data['Sender']=$this->shipment_model->getCustomer();
        
        $this->loadViews("admin/edit_shipment", $this->global, $this->data , NULL);
    }
    public function UpdateShipment()
    {
        // $weight= $this->input->post('weight').$this->input->post('unit');
         
        $data = array('office_id'=>$this->input->post('office'),'receiver_name'=>$this->input->post('r_name'),'email_id'=>$this->input->post('email'),'mobile_no'=>$this->input->post('phone'),'address'=>$this->input->post('address'),'state'=>$this->input->post('state'),'city'=>$this->input->post('city'),'postal_code'=>$this->input->post('pcode'),'item_type'=>$this->input->post('item_type'),'item_name'=>$this->input->post('item_name'),'item_desc'=>$this->input->post('item_description'),'qty'=>$this->input->post('qty'),'length'=>$this->input->post('length'),'width'=>$this->input->post('width'),'height'=>$this->input->post('height'),'weight'=>$this->input->post('weight'),'unit'=>$this->input->post('unit'),'price'=>$this->input->post('price'),'crt_by'=>$this->session->userdata('userId'));
            
        $result = $this->shipment_model->Update_Shipment($data);
        if($result){
            redirect('shipmentlist');
        } 
    }
}
